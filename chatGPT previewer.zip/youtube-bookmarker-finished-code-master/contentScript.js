(() => {
const closeDialogues=()=>
{
  document.getElementById('dialog-close').addEventListener('click', closeDialoguescard)
};
const closeDialoguescard=()=>{
      document.getElementById('IframeClass').style.display='none'
}
  const showUI=()=>{
    var newDiv = document.createElement('div');
    newDiv.className = "bg-dark";
    CodeBoxlength = document.getElementsByClassName('!whitespace-pre ')
    UidataLength = document.getElementsByClassName('!whitespace-pre ')?.length

    for (let index = 0; index < CodeBoxlength.length; index++) {
      const code = document.getElementsByClassName('!whitespace-pre ')[index];

      
    }


    const lastUiData = document.getElementsByClassName('!whitespace-pre ')[UidataLength-1]?.innerHTML || document.getElementsByClassName('!whitespace-pre ')[UidataLength]?.innerHTML 
    newDiv.textContent = lastUiData?.replace('/&gt/g','');
    var parser = new DOMParser();
    var doc = parser.parseFromString(lastUiData, 'text/html');
    var newCode = doc?.body?.innerHTML
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')?.replace(/<span[^>]*>|<\/span>/g, '');
    try {
      var doc = document.getElementById('IframeId')?.contentWindow.document.getElementById('uiShowDiv');
    } catch (error) {
console.log('error');      
    }
    // doc.open();
    // doc.write(newCode);
    doc.innerHTML = newCode||'no Preview';
  }


const  runnner =()=> setInterval( checkBtnClicked,1);

const checkBtnClicked = () =>{
var sendButton = document.querySelector('[data-testid="send-button"]') || document.querySelector('mb-1 mr-1 flex h-8 w-8 items-center justify-center rounded-full bg-black text-white transition-colors hover:opacity-70 focus-visible:outline-none focus-visible:outline-black disabled:bg-[#D7D7D7] disabled:text-[#f4f4f4] disabled:hover:opacity-100 dark:bg-white dark:text-black dark:focus-visible:outline-white disabled:dark:bg-token-text-quaternary dark:disabled:text-token-main-surface-secondary');
if(sendButton){
  sendButton.addEventListener('click', function(event) {
    console.log("shwoUI called");
    showUI();
    });

    // pending ....need to add click enter event in this 

sendButton.addEventListener('keypress',function(event){
  if (event.key === 'Enter' || event.key === 13) {
    event.preventDefault();
    sendButton.click();
  }
})

  }
}


  const iframeDiv=()=>{
    
    var iframe = document.createElement('iframe');
    iframe.src = "about:blank"; // Set a blank page initially
    iframe.width = '400';
    iframe.className = 'IframeClass';
    iframe.id = 'IframeId';
    iframe.height = '700vh';
    // Find the container element in the DOM where you want to inject the iframe
    if (document.querySelector('.relative.z-0.flex.h-full.w-full.overflow-hidden')) {
      document.querySelector('.relative.z-0.flex.h-full.w-full.overflow-hidden').appendChild(iframe);
     } else {
       console.error('Target element not found!');
     }
    var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

    //close icon 
     const closeDialogues = document.createElement('title');
     closeDialogues.innerHTML ='Close'
     closeDialogues.className = 'close-dialog';
     closeDialogues.style = ` style="
     background-color: #f44336;
     color: white;
     border: none;
     border-radius: 50%;
     cursor: pointer;
     padding: 10px 15px;
     position: absolute;
     top: 10px;
     right: 10px;`
    iframeDocument.body.appendChild(closeDialogues);

    //end
    var div = iframeDocument.createElement('div');
    div.className = 'uiShowDiv';
    div.id = 'uiShowDiv'; 
    div.style.padding = '20px';
    div.style.resize = 'both';
    div.overflow='auto'
    div.style.color = 'white';


    var div = iframeDocument.createElement('div');
    div.className = 'uiShowDiv';
    div.id = 'uiShowDiv'; 
    div.style.padding = '20px';
    div.style.resize = 'both';
    div.overflow='auto'
    div.style.color = 'white';
    // Append the div to the iframe's document body

    iframeDocument.body.appendChild(div);


  } 

document.addEventListener("DOMContentLoaded", async () => {
});
  chrome.runtime.onMessage.addListener((obj, sender, response) => {
    const { type, value, videoId } = obj;
    if(!document.getElementsByClassName('IframeClass').length || !document.getElementsByClassName('IframeClass')){
      iframeDiv()
    }
    runnner()
  });
})();
 