import { getActiveTabURL } from "./utils.js";

const addNewBookmark = (bookmarks, bookmark) => {
  const bookmarkTitleElement = document.createElement("div");
  const controlsElement = document.createElement("div");
  const newBookmarkElement = document.createElement("div");

  bookmarkTitleElement.textContent = bookmark.desc;
  bookmarkTitleElement.className = "bookmark-title";
  controlsElement.className = "bookmark-controls";

  setBookmarkAttributes("play", onPlay, controlsElement);
  setBookmarkAttributes("delete", onDelete, controlsElement);

  newBookmarkElement.id = "bookmark-" + bookmark.time;
  newBookmarkElement.className = "bookmark";
  newBookmarkElement.setAttribute("timestamp", bookmark.time);

  newBookmarkElement.appendChild(bookmarkTitleElement);
  newBookmarkElement.appendChild(controlsElement);
  bookmarks.appendChild(newBookmarkElement);
};



document.addEventListener("DOMContentLoaded", async () => {
  checkURL();
});

function checkURL() {
  const activeTab = getActiveTabURL();
  if (activeTab.url.includes("chatgpt")) {
  } else {
    const container = document.body
    if (container) {
      container.innerHTML = '<div class="title">This is not a ChatGPT page.</div>';
    }
  }
}

// Function to get active tab URL
// function getActiveTabURL() {
//   return { url: window.location.href }; // Mocking function for demonstration
// }

// Check URL periodically
setInterval(checkURL, 1000); // Adjust the interval as needed


